# blog-manager

Permissions
- canCreate
- canEdit
- canDelete
- canView

Roles
- Admin
- User
- Guest


Seed users

- Admin
```
  admin@bm.com
  admin
```

- User
```
  user@bm.com
  user
```

- Guest
```
  guest@bm.com
  guest
```