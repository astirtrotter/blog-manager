﻿exports.error = {
  NotExistUser: 'not exist user',
  AlreadyExistUser: 'already exsiting user',
  FindingUser: 'finding user error',
  InvalidDetails: 'invalid details',
  SavingData: 'saving data error',
  UserRoleError: 'user role error',
};
